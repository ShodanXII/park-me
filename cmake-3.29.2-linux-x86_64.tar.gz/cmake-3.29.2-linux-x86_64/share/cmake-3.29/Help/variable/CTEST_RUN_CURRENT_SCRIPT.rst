CTEST_RUN_CURRENT_SCRIPT
------------------------

.. versionadded:: 3.11

Setting this to 0 prevents :manual:`ctest(1)` from being run again when it
reaches the end of a script run by calling :option:`ctest -S`.
