CTEST_SCP_COMMAND
-----------------

.. versionadded:: 3.1

Legacy option.  Not used.
