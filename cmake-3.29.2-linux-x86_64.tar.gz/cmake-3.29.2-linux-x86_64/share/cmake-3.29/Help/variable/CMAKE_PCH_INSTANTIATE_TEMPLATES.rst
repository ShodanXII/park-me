CMAKE_PCH_INSTANTIATE_TEMPLATES
-------------------------------

.. versionadded:: 3.19

This variable is used to initialize the :prop_tgt:`PCH_INSTANTIATE_TEMPLATES`
property of targets when they are created.
