CMAKE_VS_SDK_LIBRARY_WINRT_DIRECTORIES
--------------------------------------

.. versionadded:: 3.12

This variable allows to override Visual Studio default Library WinRT
Directories.
