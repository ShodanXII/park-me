CMAKE_VERBOSE_MAKEFILE
----------------------

Enable verbose output from Makefile builds.

This variable is a cache entry initialized (to ``FALSE``) by
the :command:`project` command.  Users may enable the option
in their local build tree to get more verbose output from
Makefile builds and show each command line as it is launched.
